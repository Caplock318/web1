from datetime import timedelta

from flask import render_template
from flask import Flask

app = Flask(__name__)
if __name__=='__main__':
    app.run(debug=False)


app.send_file_max_age_default = timedelta(seconds=1)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/bastable')
def bas_table():
    return render_template('basic_table.html')

@app.route('/blank_f')
def blank_op():
    return render_template('blank.html')

@app.route('/buttons_f')
def buttons_op():
    return render_template('buttons.html')

@app.route('/calendar_f')
def calendar_op():
    return render_template('calendar.html')

@app.route('/chartjs_f')
def chartjs_op():
    return render_template('chartjs.html')

@app.route('/component')
def compon():
    return render_template('form_component.html')

@app.route('/gallery_f')
def gallery_op():
    return render_template('gallery.html')

@app.route('/general_f')
def general_op():
    return render_template('general.html')

@app.route('/lock_f')
def lock_op():
    return render_template('lock_screen.html')

@app.route('/login_f')
def login_op():
    return render_template('login.html')

@app.route('/morris_f')
def morris_op():
    return render_template('morris.html')

@app.route('/panels_f')
def panels_op():
    return render_template('panels.html')

@app.route('/restable_f')
def restable_op():
    return render_template('responsive_table.html')

@app.route('/todolist_f')
def todolist_op():
    return render_template('todo_list.html')